<?php
for($i=1;$i<=151;$i++){
   $data[]=sprintf('%03d', $i);
}
?>

<!DOCTYPE html>
<html lang="ja">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/style.css">
   <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
   <title>いちらん</title>
</head>

<body>

   <div id="parent">
   <img src="img/poke_frame.svg" alt="">


      <div id="box">
         <div id="inner_box">
            <?php foreach($data as $row){?>
            <a href="detail.php?id=<?php echo $row;?>">
            <ul class="poke_data">
               <li><?php echo $row ;?></li>
               <li>名前</li>
            </ul>
            </a>
            <?php } ?>

         </div><!-- /.inner_box -->
      </div><!-- /.box -->

      <form action="search_name.php" method="get">
         <label><input type="text" name="name" class="inputForm"></label>
         <input type="image" src="img/search.png" class="submitBtn">
      </form>
      <div id="typeBtn"></div>
      <div id="ent_btn"></div>
      <div id="list_btn"><a href="list.php"></a></div>
      <div id="cry_btn"></div>
      <div id="sub_disp">
         <p>いちらん</p>
      </div>

      <script src="main.js"></script>
   </div><!-- /.parent -->


</body>

</html>