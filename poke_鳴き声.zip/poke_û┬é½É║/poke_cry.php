<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- <link rel="stylesheet" href="style.css"> -->
<title>鳴き声</title>
</head>
<body>
   <table border=1>
      <?php for($i=1;$i<=151;$i++){
         $id=sprintf('%03d', $i);?>
      <tr>
         <td>
         <?php echo $id;?>
         </td>
         <td>
            <a href="poke_cry_output.php?num=<?php echo $id;?>">鳴き声</a>
         </td>

      </tr>
      <?php }?>
   </table>
      

</body>
</html>