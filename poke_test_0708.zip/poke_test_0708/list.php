<?php
for($i=1;$i<=151;$i++){
   $data[]=$i;
}
?>

<!DOCTYPE html>
<html lang="ja">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="style.css">
   <title>title</title>
</head>

<body>

   <div id="parent">
      <?xml version="1.0" encoding="utf-8"?>
      <!-- Generator: Adobe Illustrator 26.3.1, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
      <svg version="1.1" id="レイヤー_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
         x="0px" y="0px" viewBox="0 0 798.5 709.5" style="enable-background:new 0 0 798.5 709.5;" xml:space="preserve">
         <style type="text/css">
            .st0 {
               fill: #FFFFFF;
            }
         </style>
         <image style="overflow:visible;enable-background:new    ;" width="1366" height="768" xlink:href="DAD8EEEF.png"
            transform="matrix(1 0 0 1 -314 -30.5354)">
         </image>
         <path class="st0" d="M64,125.5l3,543h269v-585H157l-39,39C118,122.5,64,122.5,64,125.5z" />
      </svg>


      <div id="box">
         <div id="inner_box">
            <?php foreach($data as $row){?>
            <a href="detail-<?php echo $row;?>.php">
            <ul class="poke_data">
               <li><?php echo $row ;?></li>
               <li>名前</li>
            </ul>
            </a>
            <?php } ?>

         </div><!-- /.inner_box -->

      </div><!-- /.box -->
      <form action="" method="get">
         <label><input type="text" name="" class="inputForm"></label>
         <input type="submit" value="🔎" class="submitBtn">
      </form>
      <div id="typeBtn"></div>

      <script language="javascript" type="text/javascript">
         const typeBtn = document.getElementById("typeBtn");
         var type = ['Normal', 'Fire', 'Water', 'Grass', 'Electric', 'Ice', 'Fighting', 'Posion', 'Ground', 'Flying', 'Psychic', 'Bug', 'Rock', 'Ghost', 'Dragon'];

         for (let i = 0; i < 3; i++) {
            const newDiv = document.createElement("div");
            for (let j = 0; j < 5; j++) {
               const newBtn = document.createElement("button");
               newBtn.innerHTML = i * 5 + j;

               newBtn.onclick = () => {
                  console.log(`${newBtn.innerHTML}が押されました！`);
                  console.log(type[newBtn.innerHTML]);
               }
               newDiv.appendChild(newBtn);
            }
            typeBtn.appendChild(newDiv);
         }
      </script>
   </div><!-- /.parent -->


</body>

</html>