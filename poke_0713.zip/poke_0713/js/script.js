$(function () {
  $('.poke_data').empty();
  const pokemonIdArray = [];
  const pokemonNameArray = [];
  for (let i = 0; i < 151; i++) {
    pokemonIdArray[i] = i + 1;
    pokemonNameArray[i] = pokeJson[i].ja;
  }
  for (let i = 0; i < 151; i++) {
    let id = pokemonIdArray[i].toString().padStart(3, '0');
    $('.poke_data').append(`<li class="detail_btn" value="${pokemonNameArray[i]}">${id}<span>${pokemonNameArray[i]}</span></li>`);
  }
});