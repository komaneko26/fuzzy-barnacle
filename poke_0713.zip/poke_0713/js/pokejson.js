window.pokeJson = [
    {
        "ja": "フシギダネ",
        "en": "Bulbasaur"
    },
    {
        "ja": "フシギソウ",
        "en": "Ivysaur"
    },
    {
        "ja": "フシギバナ",
        "en": "Venusaur"
    },
    {
        "ja": "ヒトカゲ",
        "en": "Charmander"
    },
    {
        "ja": "リザード",
        "en": "Charmeleon"
    },
    {
        "ja": "リザードン",
        "en": "Charizard"
    },
    {
        "ja": "ゼニガメ",
        "en": "Squirtle"
    },
    {
        "ja": "カメール",
        "en": "Wartortle"
    },
    {
        "ja": "カメックス",
        "en": "Blastoise"
    },
    {
        "ja": "キャタピー",
        "en": "Caterpie"
    },
    {
        "ja": "トランセル",
        "en": "Metapod"
    },
    {
        "ja": "バタフリー",
        "en": "Butterfree"
    },
    {
        "ja": "ビードル",
        "en": "Weedle"
    },
    {
        "ja": "コクーン",
        "en": "Kakuna"
    },
    {
        "ja": "スピアー",
        "en": "Beedrill"
    },
    {
        "ja": "ポッポ",
        "en": "Pidgey"
    },
    {
        "ja": "ピジョン",
        "en": "Pidgeotto"
    },
    {
        "ja": "ピジョット",
        "en": "Pidgeot"
    },
    {
        "ja": "コラッタ",
        "en": "Rattata"
    },
    {
        "ja": "ラッタ",
        "en": "Raticate"
    },
    {
        "ja": "オニスズメ",
        "en": "Spearow"
    },
    {
        "ja": "オニドリル",
        "en": "Fearow"
    },
    {
        "ja": "アーボ",
        "en": "Ekans"
    },
    {
        "ja": "アーボック",
        "en": "Arbok"
    },
    {
        "ja": "ピカチュウ",
        "en": "Pikachu"
    },
    {
        "ja": "ライチュウ",
        "en": "Raichu"
    },
    {
        "ja": "サンド",
        "en": "Sandshrew"
    },
    {
        "ja": "サンドパン",
        "en": "Sandslash"
    },
    {
        "ja": "ニドラン♀",
        "en": "Nidoran♀"
    },
    {
        "ja": "ニドリーナ",
        "en": "Nidorina"
    },
    {
        "ja": "ニドクイン",
        "en": "Nidoqueen"
    },
    {
        "ja": "ニドラン♂",
        "en": "Nidoran♂"
    },
    {
        "ja": "ニドリーノ",
        "en": "Nidorino"
    },
    {
        "ja": "ニドキング",
        "en": "Nidoking"
    },
    {
        "ja": "ピッピ",
        "en": "Clefairy"
    },
    {
        "ja": "ピクシー",
        "en": "Clefable"
    },
    {
        "ja": "ロコン",
        "en": "Vulpix"
    },
    {
        "ja": "キュウコン",
        "en": "Ninetales"
    },
    {
        "ja": "プリン",
        "en": "Jigglypuff"
    },
    {
        "ja": "プクリン",
        "en": "Wigglytuff"
    },
    {
        "ja": "ズバット",
        "en": "Zubat"
    },
    {
        "ja": "ゴルバット",
        "en": "Golbat"
    },
    {
        "ja": "ナゾノクサ",
        "en": "Oddish"
    },
    {
        "ja": "クサイハナ",
        "en": "Gloom"
    },
    {
        "ja": "ラフレシア",
        "en": "Vileplume"
    },
    {
        "ja": "パラス",
        "en": "Paras"
    },
    {
        "ja": "パラセクト",
        "en": "Parasect"
    },
    {
        "ja": "コンパン",
        "en": "Venonat"
    },
    {
        "ja": "モルフォン",
        "en": "Venomoth"
    },
    {
        "ja": "ディグダ",
        "en": "Diglett"
    },
    {
        "ja": "ダグトリオ",
        "en": "Dugtrio"
    },
    {
        "ja": "ニャース",
        "en": "Meowth"
    },
    {
        "ja": "ペルシアン",
        "en": "Persian"
    },
    {
        "ja": "コダック",
        "en": "Psyduck"
    },
    {
        "ja": "ゴルダック",
        "en": "Golduck"
    },
    {
        "ja": "マンキー",
        "en": "Mankey"
    },
    {
        "ja": "オコリザル",
        "en": "Primeape"
    },
    {
        "ja": "ガーディ",
        "en": "Growlithe"
    },
    {
        "ja": "ウインディ",
        "en": "Arcanine"
    },
    {
        "ja": "ニョロモ",
        "en": "Poliwag"
    },
    {
        "ja": "ニョロゾ",
        "en": "Poliwhirl"
    },
    {
        "ja": "ニョロボン",
        "en": "Poliwrath"
    },
    {
        "ja": "ケーシィ",
        "en": "Abra"
    },
    {
        "ja": "ユンゲラー",
        "en": "Kadabra"
    },
    {
        "ja": "フーディン",
        "en": "Alakazam"
    },
    {
        "ja": "ワンリキー",
        "en": "Machop"
    },
    {
        "ja": "ゴーリキー",
        "en": "Machoke"
    },
    {
        "ja": "カイリキー",
        "en": "Machamp"
    },
    {
        "ja": "マダツボミ",
        "en": "Bellsprout"
    },
    {
        "ja": "ウツドン",
        "en": "Weepinbell"
    },
    {
        "ja": "ウツボット",
        "en": "Victreebel"
    },
    {
        "ja": "メノクラゲ",
        "en": "Tentacool"
    },
    {
        "ja": "ドククラゲ",
        "en": "Tentacruel"
    },
    {
        "ja": "イシツブテ",
        "en": "Geodude"
    },
    {
        "ja": "ゴローン",
        "en": "Graveler"
    },
    {
        "ja": "ゴローニャ",
        "en": "Golem"
    },
    {
        "ja": "ポニータ",
        "en": "Ponyta"
    },
    {
        "ja": "ギャロップ",
        "en": "Rapidash"
    },
    {
        "ja": "ヤドン",
        "en": "Slowpoke"
    },
    {
        "ja": "ヤドラン",
        "en": "Slowbro"
    },
    {
        "ja": "コイル",
        "en": "Magnemite"
    },
    {
        "ja": "レアコイル",
        "en": "Magneton"
    },
    {
        "ja": "カモネギ",
        "en": "Farfetch'd"
    },
    {
        "ja": "ドードー",
        "en": "Doduo"
    },
    {
        "ja": "ドードリオ",
        "en": "Dodrio"
    },
    {
        "ja": "パウワウ",
        "en": "Seel"
    },
    {
        "ja": "ジュゴン",
        "en": "Dewgong"
    },
    {
        "ja": "ベトベター",
        "en": "Grimer"
    },
    {
        "ja": "ベトベトン",
        "en": "Muk"
    },
    {
        "ja": "シェルダー",
        "en": "Shellder"
    },
    {
        "ja": "パルシェン",
        "en": "Cloyster"
    },
    {
        "ja": "ゴース",
        "en": "Gastly"
    },
    {
        "ja": "ゴースト",
        "en": "Haunter"
    },
    {
        "ja": "ゲンガー",
        "en": "Gengar"
    },
    {
        "ja": "イワーク",
        "en": "Onix"
    },
    {
        "ja": "スリープ",
        "en": "Drowzee"
    },
    {
        "ja": "スリーパー",
        "en": "Hypno"
    },
    {
        "ja": "クラブ",
        "en": "Krabby"
    },
    {
        "ja": "キングラー",
        "en": "Kingler"
    },
    {
        "ja": "ビリリダマ",
        "en": "Voltorb"
    },
    {
        "ja": "マルマイン",
        "en": "Electrode"
    },
    {
        "ja": "タマタマ",
        "en": "Exeggcute"
    },
    {
        "ja": "ナッシー",
        "en": "Exeggutor"
    },
    {
        "ja": "カラカラ",
        "en": "Cubone"
    },
    {
        "ja": "ガラガラ",
        "en": "Marowak"
    },
    {
        "ja": "サワムラー",
        "en": "Hitmonlee"
    },
    {
        "ja": "エビワラー",
        "en": "Hitmonchan"
    },
    {
        "ja": "ベロリンガ",
        "en": "Lickitung"
    },
    {
        "ja": "ドガース",
        "en": "Koffing"
    },
    {
        "ja": "マタドガス",
        "en": "Weezing"
    },
    {
        "ja": "サイホーン",
        "en": "Rhyhorn"
    },
    {
        "ja": "サイドン",
        "en": "Rhydon"
    },
    {
        "ja": "ラッキー",
        "en": "Chansey"
    },
    {
        "ja": "モンジャラ",
        "en": "Tangela"
    },
    {
        "ja": "ガルーラ",
        "en": "Kangaskhan"
    },
    {
        "ja": "タッツー",
        "en": "Horsea"
    },
    {
        "ja": "シードラ",
        "en": "Seadra"
    },
    {
        "ja": "トサキント",
        "en": "Goldeen"
    },
    {
        "ja": "アズマオウ",
        "en": "Seaking"
    },
    {
        "ja": "ヒトデマン",
        "en": "Staryu"
    },
    {
        "ja": "スターミー",
        "en": "Starmie"
    },
    {
        "ja": "バリヤード",
        "en": "Mr. Mime"
    },
    {
        "ja": "ストライク",
        "en": "Scyther"
    },
    {
        "ja": "ルージュラ",
        "en": "Jynx"
    },
    {
        "ja": "エレブー",
        "en": "Electabuzz"
    },
    {
        "ja": "ブーバー",
        "en": "Magmar"
    },
    {
        "ja": "カイロス",
        "en": "Pinsir"
    },
    {
        "ja": "ケンタロス",
        "en": "Tauros"
    },
    {
        "ja": "コイキング",
        "en": "Magikarp"
    },
    {
        "ja": "ギャラドス",
        "en": "Gyarados"
    },
    {
        "ja": "ラプラス",
        "en": "Lapras"
    },
    {
        "ja": "メタモン",
        "en": "Ditto"
    },
    {
        "ja": "イーブイ",
        "en": "Eevee"
    },
    {
        "ja": "シャワーズ",
        "en": "Vaporeon"
    },
    {
        "ja": "サンダース",
        "en": "Jolteon"
    },
    {
        "ja": "ブースター",
        "en": "Flareon"
    },
    {
        "ja": "ポリゴン",
        "en": "Porygon"
    },
    {
        "ja": "オムナイト",
        "en": "Omanyte"
    },
    {
        "ja": "オムスター",
        "en": "Omastar"
    },
    {
        "ja": "カブト",
        "en": "Kabuto"
    },
    {
        "ja": "カブトプス",
        "en": "Kabutops"
    },
    {
        "ja": "プテラ",
        "en": "Aerodactyl"
    },
    {
        "ja": "カビゴン",
        "en": "Snorlax"
    },
    {
        "ja": "フリーザー",
        "en": "Articuno"
    },
    {
        "ja": "サンダー",
        "en": "Zapdos"
    },
    {
        "ja": "ファイヤー",
        "en": "Moltres"
    },
    {
        "ja": "ミニリュウ",
        "en": "Dratini"
    },
    {
        "ja": "ハクリュー",
        "en": "Dragonair"
    },
    {
        "ja": "カイリュー",
        "en": "Dragonite"
    },
    {
        "ja": "ミュウツー",
        "en": "Mewtwo"
    },
    {
        "ja": "ミュウ",
        "en": "Mew"
    },
    {
        "ja": "チコリータ",
        "en": "Chikorita"
    },
    {
        "ja": "ベイリーフ",
        "en": "Bayleef"
    },
    {
        "ja": "メガニウム",
        "en": "Meganium"
    },
    {
        "ja": "ヒノアラシ",
        "en": "Cyndaquil"
    },
    {
        "ja": "マグマラシ",
        "en": "Quilava"
    },
    {
        "ja": "バクフーン",
        "en": "Typhlosion"
    },
    {
        "ja": "ワニノコ",
        "en": "Totodile"
    },
    {
        "ja": "アリゲイツ",
        "en": "Croconaw"
    },
    {
        "ja": "オーダイル",
        "en": "Feraligatr"
    },
    {
        "ja": "オタチ",
        "en": "Sentret"
    },
    {
        "ja": "オオタチ",
        "en": "Furret"
    },
    {
        "ja": "ホーホー",
        "en": "Hoothoot"
    },
    {
        "ja": "ヨルノズク",
        "en": "Noctowl"
    },
    {
        "ja": "レディバ",
        "en": "Ledyba"
    },
    {
        "ja": "レディアン",
        "en": "Ledian"
    },
    {
        "ja": "イトマル",
        "en": "Spinarak"
    },
    {
        "ja": "アリアドス",
        "en": "Ariados"
    },
    {
        "ja": "クロバット",
        "en": "Crobat"
    },
    {
        "ja": "チョンチー",
        "en": "Chinchou"
    },
    {
        "ja": "ランターン",
        "en": "Lanturn"
    },
    {
        "ja": "ピチュー",
        "en": "Pichu"
    },
    {
        "ja": "ピィ",
        "en": "Cleffa"
    },
    {
        "ja": "ププリン",
        "en": "Igglybuff"
    },
    {
        "ja": "トゲピー",
        "en": "Togepi"
    },
    {
        "ja": "トゲチック",
        "en": "Togetic"
    },
    {
        "ja": "ネイティ",
        "en": "Natu"
    },
    {
        "ja": "ネイティオ",
        "en": "Xatu"
    },
    {
        "ja": "メリープ",
        "en": "Mareep"
    },
    {
        "ja": "モココ",
        "en": "Flaaffy"
    },
    {
        "ja": "デンリュウ",
        "en": "Ampharos"
    },
    {
        "ja": "キレイハナ",
        "en": "Bellossom"
    },
    {
        "ja": "マリル",
        "en": "Marill"
    },
    {
        "ja": "マリルリ",
        "en": "Azumarill"
    },
    {
        "ja": "ウソッキー",
        "en": "Sudowoodo"
    },
    {
        "ja": "ニョロトノ",
        "en": "Politoed"
    },
    {
        "ja": "ハネッコ",
        "en": "Hoppip"
    },
    {
        "ja": "ポポッコ",
        "en": "Skiploom"
    },
    {
        "ja": "ワタッコ",
        "en": "Jumpluff"
    },
    {
        "ja": "エイパム",
        "en": "Aipom"
    },
    {
        "ja": "ヒマナッツ",
        "en": "Sunkern"
    },
    {
        "ja": "キマワリ",
        "en": "Sunflora"
    },
    {
        "ja": "ヤンヤンマ",
        "en": "Yanma"
    },
    {
        "ja": "ウパー",
        "en": "Wooper"
    },
    {
        "ja": "ヌオー",
        "en": "Quagsire"
    },
    {
        "ja": "エーフィ",
        "en": "Espeon"
    },
    {
        "ja": "ブラッキー",
        "en": "Umbreon"
    },
    {
        "ja": "ヤミカラス",
        "en": "Murkrow"
    },
    {
        "ja": "ヤドキング",
        "en": "Slowking"
    },
    {
        "ja": "ムウマ",
        "en": "Misdreavus"
    },
    {
        "ja": "アンノーン",
        "en": "Unown"
    },
    {
        "ja": "ソーナンス",
        "en": "Wobbuffet"
    },
    {
        "ja": "キリンリキ",
        "en": "Girafarig"
    },
    {
        "ja": "クヌギダマ",
        "en": "Pineco"
    },
    {
        "ja": "フォレトス",
        "en": "Forretress"
    },
    {
        "ja": "ノコッチ",
        "en": "Dunsparce"
    },
    {
        "ja": "グライガー",
        "en": "Gligar"
    },
    {
        "ja": "ハガネール",
        "en": "Steelix"
    },
    {
        "ja": "ブルー",
        "en": "Snubbull"
    },
    {
        "ja": "グランブル",
        "en": "Granbull"
    },
    {
        "ja": "ハリーセン",
        "en": "Qwilfish"
    },
    {
        "ja": "ハッサム",
        "en": "Scizor"
    },
    {
        "ja": "ツボツボ",
        "en": "Shuckle"
    },
    {
        "ja": "ヘラクロス",
        "en": "Heracross"
    },
    {
        "ja": "ニューラ",
        "en": "Sneasel"
    },
    {
        "ja": "ヒメグマ",
        "en": "Teddiursa"
    },
    {
        "ja": "リングマ",
        "en": "Ursaring"
    },
    {
        "ja": "マグマッグ",
        "en": "Slugma"
    },
    {
        "ja": "マグカルゴ",
        "en": "Magcargo"
    },
    {
        "ja": "ウリムー",
        "en": "Swinub"
    },
    {
        "ja": "イノムー",
        "en": "Piloswine"
    },
    {
        "ja": "サニーゴ",
        "en": "Corsola"
    },
    {
        "ja": "テッポウオ",
        "en": "Remoraid"
    },
    {
        "ja": "オクタン",
        "en": "Octillery"
    },
    {
        "ja": "デリバード",
        "en": "Delibird"
    },
    {
        "ja": "マンタイン",
        "en": "Mantine"
    },
    {
        "ja": "エアームド",
        "en": "Skarmory"
    },
    {
        "ja": "デルビル",
        "en": "Houndour"
    },
    {
        "ja": "ヘルガー",
        "en": "Houndoom"
    },
    {
        "ja": "キングドラ",
        "en": "Kingdra"
    },
    {
        "ja": "ゴマゾウ",
        "en": "Phanpy"
    },
    {
        "ja": "ドンファン",
        "en": "Donphan"
    },
    {
        "ja": "ポリゴン2",
        "en": "Porygon2"
    },
    {
        "ja": "オドシシ",
        "en": "Stantler"
    },
    {
        "ja": "ドーブル",
        "en": "Smeargle"
    },
    {
        "ja": "バルキー",
        "en": "Tyrogue"
    },
    {
        "ja": "カポエラー",
        "en": "Hitmontop"
    },
    {
        "ja": "ムチュール",
        "en": "Smoochum"
    },
    {
        "ja": "エレキッド",
        "en": "Elekid"
    },
    {
        "ja": "ブビィ",
        "en": "Magby"
    },
    {
        "ja": "ミルタンク",
        "en": "Miltank"
    },
    {
        "ja": "ハピナス",
        "en": "Blissey"
    },
    {
        "ja": "ライコウ",
        "en": "Raikou"
    },
    {
        "ja": "エンテイ",
        "en": "Entei"
    },
    {
        "ja": "スイクン",
        "en": "Suicune"
    },
    {
        "ja": "ヨーギラス",
        "en": "Larvitar"
    },
    {
        "ja": "サナギラス",
        "en": "Pupitar"
    },
    {
        "ja": "バンギラス",
        "en": "Tyranitar"
    },
    {
        "ja": "ルギア",
        "en": "Lugia"
    },
    {
        "ja": "ホウオウ",
        "en": "Ho-Oh"
    },
    {
        "ja": "セレビィ",
        "en": "Celebi"
    },
    {
        "ja": "キモリ",
        "en": "Treecko"
    },
    {
        "ja": "ジュプトル",
        "en": "Grovyle"
    },
    {
        "ja": "ジュカイン",
        "en": "Sceptile"
    },
    {
        "ja": "アチャモ",
        "en": "Torchic"
    },
    {
        "ja": "ワカシャモ",
        "en": "Combusken"
    },
    {
        "ja": "バシャーモ",
        "en": "Blaziken"
    },
    {
        "ja": "ミズゴロウ",
        "en": "Mudkip"
    },
    {
        "ja": "ヌマクロー",
        "en": "Marshtomp"
    },
    {
        "ja": "ラグラージ",
        "en": "Swampert"
    },
    {
        "ja": "ポチエナ",
        "en": "Poochyena"
    },
    {
        "ja": "グラエナ",
        "en": "Mightyena"
    },
    {
        "ja": "ジグザグマ",
        "en": "Zigzagoon"
    },
    {
        "ja": "マッスグマ",
        "en": "Linoone"
    },
    {
        "ja": "ケムッソ",
        "en": "Wurmple"
    },
    {
        "ja": "カラサリス",
        "en": "Silcoon"
    },
    {
        "ja": "アゲハント",
        "en": "Beautifly"
    },
    {
        "ja": "マユルド",
        "en": "Cascoon"
    },
    {
        "ja": "ドクケイル",
        "en": "Dustox"
    },
    {
        "ja": "ハスボー",
        "en": "Lotad"
    },
    {
        "ja": "ハスブレロ",
        "en": "Lombre"
    },
    {
        "ja": "ルンパッパ",
        "en": "Ludicolo"
    },
    {
        "ja": "タネボー",
        "en": "Seedot"
    },
    {
        "ja": "コノハナ",
        "en": "Nuzleaf"
    },
    {
        "ja": "ダーテング",
        "en": "Shiftry"
    },
    {
        "ja": "スバメ",
        "en": "Taillow"
    },
    {
        "ja": "オオスバメ",
        "en": "Swellow"
    },
    {
        "ja": "キャモメ",
        "en": "Wingull"
    },
    {
        "ja": "ペリッパー",
        "en": "Pelipper"
    },
    {
        "ja": "ラルトス",
        "en": "Ralts"
    },
    {
        "ja": "キルリア",
        "en": "Kirlia"
    },
    {
        "ja": "サーナイト",
        "en": "Gardevoir"
    },
    {
        "ja": "アメタマ",
        "en": "Surskit"
    },
    {
        "ja": "アメモース",
        "en": "Masquerain"
    },
    {
        "ja": "キノココ",
        "en": "Shroomish"
    },
    {
        "ja": "キノガッサ",
        "en": "Breloom"
    },
    {
        "ja": "ナマケロ",
        "en": "Slakoth"
    },
    {
        "ja": "ヤルキモノ",
        "en": "Vigoroth"
    },
    {
        "ja": "ケッキング",
        "en": "Slaking"
    },
    {
        "ja": "ツチニン",
        "en": "Nincada"
    },
    {
        "ja": "テッカニン",
        "en": "Ninjask"
    },
    {
        "ja": "ヌケニン",
        "en": "Shedinja"
    },
    {
        "ja": "ゴニョニョ",
        "en": "Whismur"
    },
    {
        "ja": "ドゴーム",
        "en": "Loudred"
    },
    {
        "ja": "バクオング",
        "en": "Exploud"
    },
    {
        "ja": "マクノシタ",
        "en": "Makuhita"
    },
    {
        "ja": "ハリテヤマ",
        "en": "Hariyama"
    },
    {
        "ja": "ルリリ",
        "en": "Azurill"
    },
    {
        "ja": "ノズパス",
        "en": "Nosepass"
    },
    {
        "ja": "エネコ",
        "en": "Skitty"
    },
    {
        "ja": "エネコロロ",
        "en": "Delcatty"
    },
    {
        "ja": "ヤミラミ",
        "en": "Sableye"
    },
    {
        "ja": "クチート",
        "en": "Mawile"
    },
    {
        "ja": "ココドラ",
        "en": "Aron"
    },
    {
        "ja": "コドラ",
        "en": "Lairon"
    },
    {
        "ja": "ボスゴドラ",
        "en": "Aggron"
    },
    {
        "ja": "アサナン",
        "en": "Meditite"
    },
    {
        "ja": "チャーレム",
        "en": "Medicham"
    },
    {
        "ja": "ラクライ",
        "en": "Electrike"
    },
    {
        "ja": "ライボルト",
        "en": "Manectric"
    },
    {
        "ja": "プラスル",
        "en": "Plusle"
    },
    {
        "ja": "マイナン",
        "en": "Minun"
    },
    {
        "ja": "バルビート",
        "en": "Volbeat"
    },
    {
        "ja": "イルミーゼ",
        "en": "Illumise"
    },
    {
        "ja": "ロゼリア",
        "en": "Roselia"
    },
    {
        "ja": "ゴクリン",
        "en": "Gulpin"
    },
    {
        "ja": "マルノーム",
        "en": "Swalot"
    },
    {
        "ja": "キバニア",
        "en": "Carvanha"
    },
    {
        "ja": "サメハダー",
        "en": "Sharpedo"
    },
    {
        "ja": "ホエルコ",
        "en": "Wailmer"
    },
    {
        "ja": "ホエルオー",
        "en": "Wailord"
    },
    {
        "ja": "ドンメル",
        "en": "Numel"
    },
    {
        "ja": "バクーダ",
        "en": "Camerupt"
    },
    {
        "ja": "コータス",
        "en": "Torkoal"
    },
    {
        "ja": "バネブー",
        "en": "Spoink"
    },
    {
        "ja": "ブーピッグ",
        "en": "Grumpig"
    },
    {
        "ja": "パッチール",
        "en": "Spinda"
    },
    {
        "ja": "ナックラー",
        "en": "Trapinch"
    },
    {
        "ja": "ビブラーバ",
        "en": "Vibrava"
    },
    {
        "ja": "フライゴン",
        "en": "Flygon"
    },
    {
        "ja": "サボネア",
        "en": "Cacnea"
    },
    {
        "ja": "ノクタス",
        "en": "Cacturne"
    },
    {
        "ja": "チルット",
        "en": "Swablu"
    },
    {
        "ja": "チルタリス",
        "en": "Altaria"
    },
    {
        "ja": "ザングース",
        "en": "Zangoose"
    },
    {
        "ja": "ハブネーク",
        "en": "Seviper"
    },
    {
        "ja": "ルナトーン",
        "en": "Lunatone"
    },
    {
        "ja": "ソルロック",
        "en": "Solrock"
    },
    {
        "ja": "ドジョッチ",
        "en": "Barboach"
    },
    {
        "ja": "ナマズン",
        "en": "Whiscash"
    },
    {
        "ja": "ヘイガニ",
        "en": "Corphish"
    },
    {
        "ja": "シザリガー",
        "en": "Crawdaunt"
    },
    {
        "ja": "ヤジロン",
        "en": "Baltoy"
    },
    {
        "ja": "ネンドール",
        "en": "Claydol"
    },
    {
        "ja": "リリーラ",
        "en": "Lileep"
    },
    {
        "ja": "ユレイドル",
        "en": "Cradily"
    },
    {
        "ja": "アノプス",
        "en": "Anorith"
    },
    {
        "ja": "アーマルド",
        "en": "Armaldo"
    },
    {
        "ja": "ヒンバス",
        "en": "Feebas"
    },
    {
        "ja": "ミロカロス",
        "en": "Milotic"
    },
    {
        "ja": "ポワルン",
        "en": "Castform"
    },
    {
        "ja": "カクレオン",
        "en": "Kecleon"
    },
    {
        "ja": "カゲボウズ",
        "en": "Shuppet"
    },
    {
        "ja": "ジュペッタ",
        "en": "Banette"
    },
    {
        "ja": "ヨマワル",
        "en": "Duskull"
    },
    {
        "ja": "サマヨール",
        "en": "Dusclops"
    },
    {
        "ja": "トロピウス",
        "en": "Tropius"
    },
    {
        "ja": "チリーン",
        "en": "Chimecho"
    },
    {
        "ja": "アブソル",
        "en": "Absol"
    },
    {
        "ja": "ソーナノ",
        "en": "Wynaut"
    },
    {
        "ja": "ユキワラシ",
        "en": "Snorunt"
    },
    {
        "ja": "オニゴーリ",
        "en": "Glalie"
    },
    {
        "ja": "タマザラシ",
        "en": "Spheal"
    },
    {
        "ja": "トドグラー",
        "en": "Sealeo"
    },
    {
        "ja": "トドゼルガ",
        "en": "Walrein"
    },
    {
        "ja": "パールル",
        "en": "Clamperl"
    },
    {
        "ja": "ハンテール",
        "en": "Huntail"
    },
    {
        "ja": "サクラビス",
        "en": "Gorebyss"
    },
    {
        "ja": "ジーランス",
        "en": "Relicanth"
    },
    {
        "ja": "ラブカス",
        "en": "Luvdisc"
    },
    {
        "ja": "タツベイ",
        "en": "Bagon"
    },
    {
        "ja": "コモルー",
        "en": "Shelgon"
    },
    {
        "ja": "ボーマンダ",
        "en": "Salamence"
    },
    {
        "ja": "ダンバル",
        "en": "Beldum"
    },
    {
        "ja": "メタング",
        "en": "Metang"
    },
    {
        "ja": "メタグロス",
        "en": "Metagross"
    },
    {
        "ja": "レジロック",
        "en": "Regirock"
    },
    {
        "ja": "レジアイス",
        "en": "Regice"
    },
    {
        "ja": "レジスチル",
        "en": "Registeel"
    },
    {
        "ja": "ラティアス",
        "en": "Latias"
    },
    {
        "ja": "ラティオス",
        "en": "Latios"
    },
    {
        "ja": "カイオーガ",
        "en": "Kyogre"
    },
    {
        "ja": "グラードン",
        "en": "Groudon"
    },
    {
        "ja": "レックウザ",
        "en": "Rayquaza"
    },
    {
        "ja": "ジラーチ",
        "en": "Jirachi"
    },
    {
        "ja": "デオキシス",
        "en": "Deoxys"
    },
    {
        "ja": "ナエトル",
        "en": "Turtwig"
    },
    {
        "ja": "ハヤシガメ",
        "en": "Grotle"
    },
    {
        "ja": "ドダイトス",
        "en": "Torterra"
    },
    {
        "ja": "ヒコザル",
        "en": "Chimchar"
    },
    {
        "ja": "モウカザル",
        "en": "Monferno"
    },
    {
        "ja": "ゴウカザル",
        "en": "Infernape"
    },
    {
        "ja": "ポッチャマ",
        "en": "Piplup"
    },
    {
        "ja": "ポッタイシ",
        "en": "Prinplup"
    },
    {
        "ja": "エンペルト",
        "en": "Empoleon"
    },
    {
        "ja": "ムックル",
        "en": "Starly"
    },
    {
        "ja": "ムクバード",
        "en": "Staravia"
    },
    {
        "ja": "ムクホーク",
        "en": "Staraptor"
    },
    {
        "ja": "ビッパ",
        "en": "Bidoof"
    },
    {
        "ja": "ビーダル",
        "en": "Bibarel"
    },
    {
        "ja": "コロボーシ",
        "en": "Kricketot"
    },
    {
        "ja": "コロトック",
        "en": "Kricketune"
    },
    {
        "ja": "コリンク",
        "en": "Shinx"
    },
    {
        "ja": "ルクシオ",
        "en": "Luxio"
    },
    {
        "ja": "レントラー",
        "en": "Luxray"
    },
    {
        "ja": "スボミー",
        "en": "Budew"
    },
    {
        "ja": "ロズレイド",
        "en": "Roserade"
    },
    {
        "ja": "ズガイドス",
        "en": "Cranidos"
    },
    {
        "ja": "ラムパルド",
        "en": "Rampardos"
    },
    {
        "ja": "タテトプス",
        "en": "Shieldon"
    },
    {
        "ja": "トリデプス",
        "en": "Bastiodon"
    },
    {
        "ja": "ミノムッチ",
        "en": "Burmy"
    },
    {
        "ja": "ミノマダム",
        "en": "Wormadam"
    },
    {
        "ja": "ガーメイル",
        "en": "Mothim"
    },
    {
        "ja": "ミツハニー",
        "en": "Combee"
    },
    {
        "ja": "ビークイン",
        "en": "Vespiquen"
    },
    {
        "ja": "パチリス",
        "en": "Pachirisu"
    },
    {
        "ja": "ブイゼル",
        "en": "Buizel"
    },
    {
        "ja": "フローゼル",
        "en": "Floatzel"
    },
    {
        "ja": "チェリンボ",
        "en": "Cherubi"
    },
    {
        "ja": "チェリム",
        "en": "Cherrim"
    },
    {
        "ja": "カラナクシ",
        "en": "Shellos"
    },
    {
        "ja": "トリトドン",
        "en": "Gastrodon"
    },
    {
        "ja": "エテボース",
        "en": "Ambipom"
    },
    {
        "ja": "フワンテ",
        "en": "Drifloon"
    },
    {
        "ja": "フワライド",
        "en": "Drifblim"
    },
    {
        "ja": "ミミロル",
        "en": "Buneary"
    },
    {
        "ja": "ミミロップ",
        "en": "Lopunny"
    },
    {
        "ja": "ムウマージ",
        "en": "Mismagius"
    },
    {
        "ja": "ドンカラス",
        "en": "Honchkrow"
    },
    {
        "ja": "ニャルマー",
        "en": "Glameow"
    },
    {
        "ja": "ブニャット",
        "en": "Purugly"
    },
    {
        "ja": "リーシャン",
        "en": "Chingling"
    },
    {
        "ja": "スカンプー",
        "en": "Stunky"
    },
    {
        "ja": "スカタンク",
        "en": "Skuntank"
    },
    {
        "ja": "ドーミラー",
        "en": "Bronzor"
    },
    {
        "ja": "ドータクン",
        "en": "Bronzong"
    },
    {
        "ja": "ウソハチ",
        "en": "Bonsly"
    },
    {
        "ja": "マネネ",
        "en": "Mime Jr."
    },
    {
        "ja": "ピンプク",
        "en": "Happiny"
    },
    {
        "ja": "ペラップ",
        "en": "Chatot"
    },
    {
        "ja": "ミカルゲ",
        "en": "Spiritomb"
    },
    {
        "ja": "フカマル",
        "en": "Gible"
    },
    {
        "ja": "ガバイト",
        "en": "Gabite"
    },
    {
        "ja": "ガブリアス",
        "en": "Garchomp"
    },
    {
        "ja": "ゴンベ",
        "en": "Munchlax"
    },
    {
        "ja": "リオル",
        "en": "Riolu"
    },
    {
        "ja": "ルカリオ",
        "en": "Lucario"
    },
    {
        "ja": "ヒポポタス",
        "en": "Hippopotas"
    },
    {
        "ja": "カバルドン",
        "en": "Hippowdon"
    },
    {
        "ja": "スコルピ",
        "en": "Skorupi"
    },
    {
        "ja": "ドラピオン",
        "en": "Drapion"
    },
    {
        "ja": "グレッグル",
        "en": "Croagunk"
    },
    {
        "ja": "ドクロッグ",
        "en": "Toxicroak"
    },
    {
        "ja": "マスキッパ",
        "en": "Carnivine"
    },
    {
        "ja": "ケイコウオ",
        "en": "Finneon"
    },
    {
        "ja": "ネオラント",
        "en": "Lumineon"
    },
    {
        "ja": "タマンタ",
        "en": "Mantyke"
    },
    {
        "ja": "ユキカブリ",
        "en": "Snover"
    },
    {
        "ja": "ユキノオー",
        "en": "Abomasnow"
    },
    {
        "ja": "マニューラ",
        "en": "Weavile"
    },
    {
        "ja": "ジバコイル",
        "en": "Magnezone"
    },
    {
        "ja": "ベロベルト",
        "en": "Lickilicky"
    },
    {
        "ja": "ドサイドン",
        "en": "Rhyperior"
    },
    {
        "ja": "モジャンボ",
        "en": "Tangrowth"
    },
    {
        "ja": "エレキブル",
        "en": "Electivire"
    },
    {
        "ja": "ブーバーン",
        "en": "Magmortar"
    },
    {
        "ja": "トゲキッス",
        "en": "Togekiss"
    },
    {
        "ja": "メガヤンマ",
        "en": "Yanmega"
    },
    {
        "ja": "リーフィア",
        "en": "Leafeon"
    },
    {
        "ja": "グレイシア",
        "en": "Glaceon"
    },
    {
        "ja": "グライオン",
        "en": "Gliscor"
    },
    {
        "ja": "マンムー",
        "en": "Mamoswine"
    },
    {
        "ja": "ポリゴンZ",
        "en": "Porygon-Z"
    },
    {
        "ja": "エルレイド",
        "en": "Gallade"
    },
    {
        "ja": "ダイノーズ",
        "en": "Probopass"
    },
    {
        "ja": "ヨノワール",
        "en": "Dusknoir"
    },
    {
        "ja": "ユキメノコ",
        "en": "Froslass"
    },
    {
        "ja": "ロトム",
        "en": "Rotom"
    },
    {
        "ja": "ユクシー",
        "en": "Uxie"
    },
    {
        "ja": "エムリット",
        "en": "Mesprit"
    },
    {
        "ja": "アグノム",
        "en": "Azelf"
    },
    {
        "ja": "ディアルガ",
        "en": "Dialga"
    },
    {
        "ja": "パルキア",
        "en": "Palkia"
    },
    {
        "ja": "ヒードラン",
        "en": "Heatran"
    },
    {
        "ja": "レジギガス",
        "en": "Regigigas"
    },
    {
        "ja": "ギラティナ",
        "en": "Giratina"
    },
    {
        "ja": "クレセリア",
        "en": "Cresselia"
    },
    {
        "ja": "フィオネ",
        "en": "Phione"
    },
    {
        "ja": "マナフィ",
        "en": "Manaphy"
    },
    {
        "ja": "ダークライ",
        "en": "Darkrai"
    },
    {
        "ja": "シェイミ",
        "en": "Shaymin"
    },
    {
        "ja": "アルセウス",
        "en": "Arceus"
    },
    {
        "ja": "ビクティニ",
        "en": "Victini"
    },
    {
        "ja": "ツタージャ",
        "en": "Snivy"
    },
    {
        "ja": "ジャノビー",
        "en": "Servine"
    },
    {
        "ja": "ジャローダ",
        "en": "Serperior"
    },
    {
        "ja": "ポカブ",
        "en": "Tepig"
    },
    {
        "ja": "チャオブー",
        "en": "Pignite"
    },
    {
        "ja": "エンブオー",
        "en": "Emboar"
    },
    {
        "ja": "ミジュマル",
        "en": "Oshawott"
    },
    {
        "ja": "フタチマル",
        "en": "Dewott"
    },
    {
        "ja": "ダイケンキ",
        "en": "Samurott"
    },
    {
        "ja": "ミネズミ",
        "en": "Patrat"
    },
    {
        "ja": "ミルホッグ",
        "en": "Watchog"
    },
    {
        "ja": "ヨーテリー",
        "en": "Lillipup"
    },
    {
        "ja": "ハーデリア",
        "en": "Herdier"
    },
    {
        "ja": "ムーランド",
        "en": "Stoutland"
    },
    {
        "ja": "チョロネコ",
        "en": "Purrloin"
    },
    {
        "ja": "レパルダス",
        "en": "Liepard"
    },
    {
        "ja": "ヤナップ",
        "en": "Pansage"
    },
    {
        "ja": "ヤナッキー",
        "en": "Simisage"
    },
    {
        "ja": "バオップ",
        "en": "Pansear"
    },
    {
        "ja": "バオッキー",
        "en": "Simisear"
    },
    {
        "ja": "ヒヤップ",
        "en": "Panpour"
    },
    {
        "ja": "ヒヤッキー",
        "en": "Simipour"
    },
    {
        "ja": "ムンナ",
        "en": "Munna"
    },
    {
        "ja": "ムシャーナ",
        "en": "Musharna"
    },
    {
        "ja": "マメパト",
        "en": "Pidove"
    },
    {
        "ja": "ハトーボー",
        "en": "Tranquill"
    },
    {
        "ja": "ケンホロウ",
        "en": "Unfezant"
    },
    {
        "ja": "シママ",
        "en": "Blitzle"
    },
    {
        "ja": "ゼブライカ",
        "en": "Zebstrika"
    },
    {
        "ja": "ダンゴロ",
        "en": "Roggenrola"
    },
    {
        "ja": "ガントル",
        "en": "Boldore"
    },
    {
        "ja": "ギガイアス",
        "en": "Gigalith"
    },
    {
        "ja": "コロモリ",
        "en": "Woobat"
    },
    {
        "ja": "ココロモリ",
        "en": "Swoobat"
    },
    {
        "ja": "モグリュー",
        "en": "Drilbur"
    },
    {
        "ja": "ドリュウズ",
        "en": "Excadrill"
    },
    {
        "ja": "タブンネ",
        "en": "Audino"
    },
    {
        "ja": "ドッコラー",
        "en": "Timburr"
    },
    {
        "ja": "ドテッコツ",
        "en": "Gurdurr"
    },
    {
        "ja": "ローブシン",
        "en": "Conkeldurr"
    },
    {
        "ja": "オタマロ",
        "en": "Tympole"
    },
    {
        "ja": "ガマガル",
        "en": "Palpitoad"
    },
    {
        "ja": "ガマゲロゲ",
        "en": "Seismitoad"
    },
    {
        "ja": "ナゲキ",
        "en": "Throh"
    },
    {
        "ja": "ダゲキ",
        "en": "Sawk"
    },
    {
        "ja": "クルミル",
        "en": "Sewaddle"
    },
    {
        "ja": "クルマユ",
        "en": "Swadloon"
    },
    {
        "ja": "ハハコモリ",
        "en": "Leavanny"
    },
    {
        "ja": "フシデ",
        "en": "Venipede"
    },
    {
        "ja": "ホイーガ",
        "en": "Whirlipede"
    },
    {
        "ja": "ペンドラー",
        "en": "Scolipede"
    },
    {
        "ja": "モンメン",
        "en": "Cottonee"
    },
    {
        "ja": "エルフーン",
        "en": "Whimsicott"
    },
    {
        "ja": "チュリネ",
        "en": "Petilil"
    },
    {
        "ja": "ドレディア",
        "en": "Lilligant"
    },
    {
        "ja": "バスラオ",
        "en": "Basculin"
    },
    {
        "ja": "メグロコ",
        "en": "Sandile"
    },
    {
        "ja": "ワルビル",
        "en": "Krokorok"
    },
    {
        "ja": "ワルビアル",
        "en": "Krookodile"
    },
    {
        "ja": "ダルマッカ",
        "en": "Darumaka"
    },
    {
        "ja": "ヒヒダルマ",
        "en": "Darmanitan"
    },
    {
        "ja": "マラカッチ",
        "en": "Maractus"
    },
    {
        "ja": "イシズマイ",
        "en": "Dwebble"
    },
    {
        "ja": "イワパレス",
        "en": "Crustle"
    },
    {
        "ja": "ズルッグ",
        "en": "Scraggy"
    },
    {
        "ja": "ズルズキン",
        "en": "Scrafty"
    },
    {
        "ja": "シンボラー",
        "en": "Sigilyph"
    },
    {
        "ja": "デスマス",
        "en": "Yamask"
    },
    {
        "ja": "デスカーン",
        "en": "Cofagrigus"
    },
    {
        "ja": "プロトーガ",
        "en": "Tirtouga"
    },
    {
        "ja": "アバゴーラ",
        "en": "Carracosta"
    },
    {
        "ja": "アーケン",
        "en": "Archen"
    },
    {
        "ja": "アーケオス",
        "en": "Archeops"
    },
    {
        "ja": "ヤブクロン",
        "en": "Trubbish"
    },
    {
        "ja": "ダストダス",
        "en": "Garbodor"
    },
    {
        "ja": "ゾロア",
        "en": "Zorua"
    },
    {
        "ja": "ゾロアーク",
        "en": "Zoroark"
    },
    {
        "ja": "チラーミィ",
        "en": "Minccino"
    },
    {
        "ja": "チラチーノ",
        "en": "Cinccino"
    },
    {
        "ja": "ゴチム",
        "en": "Gothita"
    },
    {
        "ja": "ゴチミル",
        "en": "Gothorita"
    },
    {
        "ja": "ゴチルゼル",
        "en": "Gothitelle"
    },
    {
        "ja": "ユニラン",
        "en": "Solosis"
    },
    {
        "ja": "ダブラン",
        "en": "Duosion"
    },
    {
        "ja": "ランクルス",
        "en": "Reuniclus"
    },
    {
        "ja": "コアルヒー",
        "en": "Ducklett"
    },
    {
        "ja": "スワンナ",
        "en": "Swanna"
    },
    {
        "ja": "バニプッチ",
        "en": "Vanillite"
    },
    {
        "ja": "バニリッチ",
        "en": "Vanillish"
    },
    {
        "ja": "バイバニラ",
        "en": "Vanilluxe"
    },
    {
        "ja": "シキジカ",
        "en": "Deerling"
    },
    {
        "ja": "メブキジカ",
        "en": "Sawsbuck"
    },
    {
        "ja": "エモンガ",
        "en": "Emolga"
    },
    {
        "ja": "カブルモ",
        "en": "Karrablast"
    },
    {
        "ja": "シュバルゴ",
        "en": "Escavalier"
    },
    {
        "ja": "タマゲタケ",
        "en": "Foongus"
    },
    {
        "ja": "モロバレル",
        "en": "Amoonguss"
    },
    {
        "ja": "プルリル",
        "en": "Frillish"
    },
    {
        "ja": "ブルンゲル",
        "en": "Jellicent"
    },
    {
        "ja": "ママンボウ",
        "en": "Alomomola"
    },
    {
        "ja": "バチュル",
        "en": "Joltik"
    },
    {
        "ja": "デンチュラ",
        "en": "Galvantula"
    },
    {
        "ja": "テッシード",
        "en": "Ferroseed"
    },
    {
        "ja": "ナットレイ",
        "en": "Ferrothorn"
    },
    {
        "ja": "ギアル",
        "en": "Klink"
    },
    {
        "ja": "ギギアル",
        "en": "Klang"
    },
    {
        "ja": "ギギギアル",
        "en": "Klinklang"
    },
    {
        "ja": "シビシラス",
        "en": "Tynamo"
    },
    {
        "ja": "シビビール",
        "en": "Eelektrik"
    },
    {
        "ja": "シビルドン",
        "en": "Eelektross"
    },
    {
        "ja": "リグレー",
        "en": "Elgyem"
    },
    {
        "ja": "オーベム",
        "en": "Beheeyem"
    },
    {
        "ja": "ヒトモシ",
        "en": "Litwick"
    },
    {
        "ja": "ランプラー",
        "en": "Lampent"
    },
    {
        "ja": "シャンデラ",
        "en": "Chandelure"
    },
    {
        "ja": "キバゴ",
        "en": "Axew"
    },
    {
        "ja": "オノンド",
        "en": "Fraxure"
    },
    {
        "ja": "オノノクス",
        "en": "Haxorus"
    },
    {
        "ja": "クマシュン",
        "en": "Cubchoo"
    },
    {
        "ja": "ツンベアー",
        "en": "Beartic"
    },
    {
        "ja": "フリージオ",
        "en": "Cryogonal"
    },
    {
        "ja": "チョボマキ",
        "en": "Shelmet"
    },
    {
        "ja": "アギルダー",
        "en": "Accelgor"
    },
    {
        "ja": "マッギョ",
        "en": "Stunfisk"
    },
    {
        "ja": "コジョフー",
        "en": "Mienfoo"
    },
    {
        "ja": "コジョンド",
        "en": "Mienshao"
    },
    {
        "ja": "クリムガン",
        "en": "Druddigon"
    },
    {
        "ja": "ゴビット",
        "en": "Golett"
    },
    {
        "ja": "ゴルーグ",
        "en": "Golurk"
    },
    {
        "ja": "コマタナ",
        "en": "Pawniard"
    },
    {
        "ja": "キリキザン",
        "en": "Bisharp"
    },
    {
        "ja": "バッフロン",
        "en": "Bouffalant"
    },
    {
        "ja": "ワシボン",
        "en": "Rufflet"
    },
    {
        "ja": "ウォーグル",
        "en": "Braviary"
    },
    {
        "ja": "バルチャイ",
        "en": "Vullaby"
    },
    {
        "ja": "バルジーナ",
        "en": "Mandibuzz"
    },
    {
        "ja": "クイタラン",
        "en": "Heatmor"
    },
    {
        "ja": "アイアント",
        "en": "Durant"
    },
    {
        "ja": "モノズ",
        "en": "Deino"
    },
    {
        "ja": "ジヘッド",
        "en": "Zweilous"
    },
    {
        "ja": "サザンドラ",
        "en": "Hydreigon"
    },
    {
        "ja": "メラルバ",
        "en": "Larvesta"
    },
    {
        "ja": "ウルガモス",
        "en": "Volcarona"
    },
    {
        "ja": "コバルオン",
        "en": "Cobalion"
    },
    {
        "ja": "テラキオン",
        "en": "Terrakion"
    },
    {
        "ja": "ビリジオン",
        "en": "Virizion"
    },
    {
        "ja": "トルネロス",
        "en": "Tornadus"
    },
    {
        "ja": "ボルトロス",
        "en": "Thundurus"
    },
    {
        "ja": "レシラム",
        "en": "Reshiram"
    },
    {
        "ja": "ゼクロム",
        "en": "Zekrom"
    },
    {
        "ja": "ランドロス",
        "en": "Landorus"
    },
    {
        "ja": "キュレム",
        "en": "Kyurem"
    },
    {
        "ja": "ケルディオ",
        "en": "Keldeo"
    },
    {
        "ja": "メロエッタ",
        "en": "Meloetta"
    },
    {
        "ja": "ゲノセクト",
        "en": "Genesect"
    },
    {
        "ja": "ハリマロン",
        "en": "Chespin"
    },
    {
        "ja": "ハリボーグ",
        "en": "Quilladin"
    },
    {
        "ja": "ブリガロン",
        "en": "Chesnaught"
    },
    {
        "ja": "フォッコ",
        "en": "Fennekin"
    },
    {
        "ja": "テールナー",
        "en": "Braixen"
    },
    {
        "ja": "マフォクシー",
        "en": "Delphox"
    },
    {
        "ja": "ケロマツ",
        "en": "Froakie"
    },
    {
        "ja": "ゲコガシラ",
        "en": "Frogadier"
    },
    {
        "ja": "ゲッコウガ",
        "en": "Greninja"
    },
    {
        "ja": "ホルビー",
        "en": "Bunnelby"
    },
    {
        "ja": "ホルード",
        "en": "Diggersby"
    },
    {
        "ja": "ヤヤコマ",
        "en": "Fletchling"
    },
    {
        "ja": "ヒノヤコマ",
        "en": "Fletchinder"
    },
    {
        "ja": "ファイアロー",
        "en": "Talonflame"
    },
    {
        "ja": "コフキムシ",
        "en": "Scatterbug"
    },
    {
        "ja": "コフーライ",
        "en": "Spewpa"
    },
    {
        "ja": "ビビヨン",
        "en": "Vivillon"
    },
    {
        "ja": "シシコ",
        "en": "Litleo"
    },
    {
        "ja": "カエンジシ",
        "en": "Pyroar"
    },
    {
        "ja": "フラベベ",
        "en": "Flab_b_"
    },
    {
        "ja": "フラエッテ",
        "en": "Floette"
    },
    {
        "ja": "フラージェス",
        "en": "Florges"
    },
    {
        "ja": "メェークル",
        "en": "Skiddo"
    },
    {
        "ja": "ゴーゴート",
        "en": "Gogoat"
    },
    {
        "ja": "ヤンチャム",
        "en": "Pancham"
    },
    {
        "ja": "ゴロンダ",
        "en": "Pangoro"
    },
    {
        "ja": "トリミアン",
        "en": "Furfrou"
    },
    {
        "ja": "ニャスパー",
        "en": "Espurr"
    },
    {
        "ja": "ニャオニクス",
        "en": "Meowstic"
    },
    {
        "ja": "ヒトツキ",
        "en": "Honedge"
    },
    {
        "ja": "ニダンギル",
        "en": "Doublade"
    },
    {
        "ja": "ギルガルド",
        "en": "Aegislash"
    },
    {
        "ja": "シュシュプ",
        "en": "Spritzee"
    },
    {
        "ja": "フレフワン",
        "en": "Aromatisse"
    },
    {
        "ja": "ペロッパフ",
        "en": "Swirlix"
    },
    {
        "ja": "ペロリーム",
        "en": "Slurpuff"
    },
    {
        "ja": "マーイーカ",
        "en": "Inkay"
    },
    {
        "ja": "カラマネロ",
        "en": "Malamar"
    },
    {
        "ja": "カメテテ",
        "en": "Binacle"
    },
    {
        "ja": "ガメノデス",
        "en": "Barbaracle"
    },
    {
        "ja": "クズモー",
        "en": "Skrelp"
    },
    {
        "ja": "ドラミドロ",
        "en": "Dragalge"
    },
    {
        "ja": "ウデッポウ",
        "en": "Clauncher"
    },
    {
        "ja": "ブロスター",
        "en": "Clawitzer"
    },
    {
        "ja": "エリキテル",
        "en": "Helioptile"
    },
    {
        "ja": "エレザード",
        "en": "Heliolisk"
    },
    {
        "ja": "チゴラス",
        "en": "Tyrunt"
    },
    {
        "ja": "ガチゴラス",
        "en": "Tyrantrum"
    },
    {
        "ja": "アマルス",
        "en": "Amaura"
    },
    {
        "ja": "アマルルガ",
        "en": "Aurorus"
    },
    {
        "ja": "ニンフィア",
        "en": "Sylveon"
    },
    {
        "ja": "ルチャブル",
        "en": "Hawlucha"
    },
    {
        "ja": "デデンネ",
        "en": "Dedenne"
    },
    {
        "ja": "メレシー",
        "en": "Carbink"
    },
    {
        "ja": "ヌメラ",
        "en": "Goomy"
    },
    {
        "ja": "ヌメイル",
        "en": "Sliggoo"
    },
    {
        "ja": "ヌメルゴン",
        "en": "Goodra"
    },
    {
        "ja": "クレッフィ",
        "en": "Klefki"
    },
    {
        "ja": "ボクレー",
        "en": "Phantump"
    },
    {
        "ja": "オーロット",
        "en": "Trevenant"
    },
    {
        "ja": "バケッチャ",
        "en": "Pumpkaboo"
    },
    {
        "ja": "パンプジン",
        "en": "Gourgeist"
    },
    {
        "ja": "カチコール",
        "en": "Bergmite"
    },
    {
        "ja": "クレベース",
        "en": "Avalugg"
    },
    {
        "ja": "オンバット",
        "en": "Noibat"
    },
    {
        "ja": "オンバーン",
        "en": "Noivern"
    },
    {
        "ja": "ゼルネアス",
        "en": "Xerneas"
    },
    {
        "ja": "イベルタル",
        "en": "Yveltal"
    },
    {
        "ja": "ジガルデ",
        "en": "Zygarde"
    },
    {
        "ja": "ディアンシー",
        "en": "Diancie"
    },
    {
        "ja": "フーパ",
        "en": "Hoopa"
    },
    {
        "ja": "ボルケニオン",
        "en": "Volcanion"
    }
]