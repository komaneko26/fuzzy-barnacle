$(function () {
  $('.poke_data').empty();
  const pokemonIdArray = [];
  const pokemonNameArray = [];
  for (let i = 0; i < 151; i++) {
    pokemonIdArray[i] = i + 1;
    pokemonNameArray[i] = pokeJson[i].ja;
  }
  for (let i = 0; i < 151; i++) {
    let id = pokemonIdArray[i].toString().padStart(3, '0');
    $('.poke_data').append(`<a href="detail.html?id=${pokemonIdArray[i]}"><li>${id}:${pokemonNameArray[i]}</li></a>`);
  }
});

$(function () {
  $('#pokemonImg').empty();
  $('#pokemonName').empty();
  const id = $('#id').val();
  // 一つ目のURL
  const urlA = 'https://pokeapi.co/api/v2/pokemon/' + id + '/';
  // 指定したURLにリクエストを送信する
  fetch(urlA)
    // レスポンスで返ってきたデータからJSONデータを抽出
    .then(response => response.json())
    .then(data => {
      // JSONデータから画像を取得
      const pokemonImg = data.sprites.front_default;
      $('#pokemonImg').append(`<p><img src="${pokemonImg}"></p>`);
    })
  // 二つ目のURL
  const urlB = 'https://pokeapi.co/api/v2/pokemon-species/' + id + '/';
  // 指定したURLにリクエストを送信する
  fetch(urlB)
    // レスポンスで返ってきたデータからJSONデータを抽出
    .then(response => response.json())
    .then(data => {
      // JSONデータから名前を取得
      const pokemonName = data.names[0].name;
      $('#pokemonName').append(`<p>${pokemonName}</p>`);
    })
});