const buttonOpen_c = document.getElementById('cry_btn');
const buttonOpen_t = document.getElementById('typeBtn');
const buttonOpen_f = document.getElementsByClassName('submitBtnImg')[0];

const modal = document.getElementById('word_modal');
const buttonClose = document.getElementsByClassName('modal_close')[0];
const mes = document.getElementsByClassName('mes')[0];


// ボタンがクリックされた時
buttonOpen_c.addEventListener('click', modalOpen_c);
buttonOpen_t.addEventListener('click', modalOpen);
buttonOpen_f.addEventListener('click', modalOpen);

// 鳴き声
function modalOpen_c() {
   modal.style.display = 'block';
   mes.innerHTML = "おしたボタンは<br>「しょうさいがめん」で<br>つかえます。";
}
// タイプと検索
function modalOpen() {
   modal.style.display = 'block';
   mes.innerHTML = "おしたボタンは<br>「いちらんがめん」で<br>つかえます。";
}

// 閉じるボタンクリック
buttonClose.addEventListener('click', modalClose);
function modalClose() {
   modal.style.display = 'none';
}