const typeBtn = document.getElementById("typeBtn");
var type = ['Normal', 'Fire', 'Water', 'Electric', 'Grass', 'Ice', 'Fighting', 'Posion', 'Ground', 'Flying', 'Psychic', 'Bug', 'Rock', 'Ghost', 'Dragon'];

for (let i = 0; i < 3; i++) {
   const newDiv = document.createElement("div");
   for (let j = 0; j < 5; j++) {
      const newBtn = document.createElement("button");
      newBtn.innerHTML = i * 5 + j;

      newBtn.onclick = () => {
         location.href = `search_type.php?type=${type[newBtn.innerHTML]}`;
         // console.log(`${newBtn.innerHTML}が押されました！`);
         // console.log(type[newBtn.innerHTML]);
         // console.log(`search_type.php?type=${type[newBtn.innerHTML]}`);
      }
      newDiv.appendChild(newBtn);
   }
   typeBtn.appendChild(newDiv);
}