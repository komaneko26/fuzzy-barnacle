<?php
if(isset($_GET['id'])){
   $innum=htmlspecialchars($_GET['id'],ENT_QUOTES,'UTF-8');
   $id=mb_convert_kana($innum,'n','UTF-8');
   $id=sprintf('%03d', $id);
}
   
?>

<!DOCTYPE html>
<html lang="ja">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/detail.css">
   <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">

   <title><?php echo '名前';?>のしょうさい</title>
</head>

<body>

   <div id="parent">
      <div class="light"></div>
      <img src="img/poke_frame.svg" alt="">
      <div id="box">
         <div id="inner_box">
            <p class='poke_img'><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png" alt="フシギダネ"></p>
            <h2><?php echo 'フシギダネ';?></h2>
            <h3><?php echo 'たね';?>ポケモン</h3>
            <h3>たかさ　<?php echo '0.7';?>m</h3>
            <h3>おもさ　<?php echo '6.9';?>kg</h3>
            <p><?php echo 'うまれたときから　せなかにしょくぶつの　タネがあって　からだと　ともに育つという';?></p>
            <a href="list.php" class="next">もどる</a>
         </div><!-- /.inner_box -->
      </div><!-- /.box -->

      <form action="" method="get">
         <label><input type="text" name="name" class="inputForm"></label>
         <input type="image" src="img/search.png" class="submitBtn">

      </form>
      <div id="typeBtn"></div>
      <div id="ent_btn"></div>
      <div id="list_btn"><a href="list.php"></a></div>
      <div id="cry_btn" onclick="sound()"></div>
      <audio id="sound" preload="auto">
         <source src="cries/<?php echo $id;?>.wav" type="audio/wav">
      </audio>
   
      <div id="sub_disp">
         <p>しょうさい<br>(<?php echo 'フシギダネ';?>)</p>
      </div>
   </div><!-- /.parent -->

      <script src="main.js"></script>
      <script>
   function sound()
   {document.getElementById( 'sound' ).play() ;}
   </script>
   


</body>

</html>